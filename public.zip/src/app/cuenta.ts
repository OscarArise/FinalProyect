export const CUENTA     = [
    {
        username: 'admin',
        password: 'admin',
        nombre: 'Admin'
    },
    {
        username: 'user',
        password: 'user',
        nombre: 'User'
    },
    {
        username: 'guest',
        password: 'guest',
        nombre: 'Guest'
    }
]