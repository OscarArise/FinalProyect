export interface Usuario {
    username: string;
    password: string;
    nombre: string;
}