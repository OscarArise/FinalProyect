export const environment = {
  firebase: {
    apiKey: "AIzaSyBkhZwSwygjJnrE6ntRpekaqe8G1-Z4Ot4",
    authDomain: "pruebasfirebase-c2278.web.app", // ← ¡Aquí está el cambio!
    projectId: "pruebasfirebase-c2278",
    storageBucket: "pruebasfirebase-c2278.appspot.com",
    messagingSenderId: "51759880341",
    appId: "1:51759880341:web:f1a95b08d1d61144b6239c",
    measurementId: "G-3WMNZRQ91Z"
  }
};
